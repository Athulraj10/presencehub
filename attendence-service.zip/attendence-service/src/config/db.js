const mysql = require("mysql2/promise");
require("dotenv").config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

pool.getConnection()
  .then(connection => {
    console.log("MySQL Connected Successfully");
    connection.release();
  })
  .catch(err => {
    console.error("MySQL Connection Failed:");
    console.error(err.message);
  });

module.exports = pool;


